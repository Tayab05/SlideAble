import 'package:flutter/material.dart';

class SlideableWidget extends StatefulWidget {
  @override
  _SlideableWidgetState createState() => _SlideableWidgetState();
}

class _SlideableWidgetState extends State<SlideableWidget> {
  double _position = 0.0;
  bool _isSliding = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragStart: (details) {
        setState(() {
          _isSliding = true;
        });
      },
      onHorizontalDragUpdate: (details) {
        setState(() {
          _position += details.delta.dx;
        });
      },
      onHorizontalDragEnd: (details) {
        setState(() {
          _isSliding = false;
          if (_position > 100) {
            _position = 200; // Snap to fully opened
          } else {
            _position = 0; // Snap to closed
          }
        });
      },
      child: Align(
        alignment: Alignment.center,
        child: Stack(
          children: [
            Positioned(
              left: _position,
              child: Container(
                width: 200,
                height: 100,
                color: Colors.black,
                child: Center(
                  child: Text(
                    'Slide me',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false, // Remove the debug banner
    home: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green, // Set the background color
        title: Text('Slideable Widget'),
      ),
      body: Center(
        child: SlideableWidget(),
      ),
    ),
  ));
}