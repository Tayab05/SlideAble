package com.example.untitled11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
